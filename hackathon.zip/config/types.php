<?php

return array( 
  array( 'basic', rand( 100, 150 ) ), 
  array( 'standard', rand( 200, 300 ) ), 
  array( 'special', rand( 500, 1000 ) ), 
  array( 'express', rand( 1500, 2000 ) )
);
